import { mkdir, copyFile, rm } from 'node:fs/promises';
const files = ['index.html', 'manifest.webmanifest', 'icon.svg', 'sw.js'];
await rm('www', { recursive: true, force: true });
await mkdir('www', { recursive: true });
for (const file of files) await copyFile(file, `www/${file}`);
console.log('Assets WATCH LAB 3D copiés dans www/.');
